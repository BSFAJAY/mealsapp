# mealApp
know about your favourites meals
This is a single page website where you can seach about any meal and you can also add it into on your favourite list

preview link : https://surajit980.github.io/mealApp/
language used : html,css,javascript and bootstrap.
